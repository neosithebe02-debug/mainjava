/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mainjava;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class MainjavaIT {
    
    public MainjavaIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     *
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Mainjava.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
     public void testUsernameCorrectlyFormatted() {
        Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
);;

        assertTrue(user.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
       Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
); ;

        assertFalse(user.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
       Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
); ;

        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
      Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith");  ;

        assertFalse(user.checkPasswordComplexity());;
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormatted() {
        Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
);;

        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormatted() {
       Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
); ;

        assertFalse(user.checkCellPhoneNumber());
    }

    @Test
    public void testLoginSuccessful() {
       Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
); ;

        boolean result = user.loginUser("kyl_1", "Ch&&sec@ke99!");

        assertTrue(result);
    }

    @Test
    public void testLoginFailed() {
       Login user = new Login(
    "kyl_1",
    "Ch&&sec@ke99!",
    "+27838969876",
    "Kyle",
    "Smith"
); ;

        boolean result = user.loginUser("kyl_1", "WrongPassword1!");

        assertFalse(result);
    }
}
    

