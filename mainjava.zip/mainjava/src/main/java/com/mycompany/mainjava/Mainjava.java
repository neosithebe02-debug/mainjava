/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainjava;


import java.util.Scanner;

/**
 *
 * @author student
 */
import java.util.Scanner;

public class Mainjava {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("===== CHAT APP =====");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter username (must contain '_' and be 6 characters long): ");
        String username = input.nextLine();

        System.out.print("Enter password (minimum 8 characters, with at least 1 uppercase, 1 number, and 1 special character): ");
        String password = input.nextLine();

        System.out.print("Enter South African cell phone number (+27XXXXXXXXX): ");
        String cellPhone = input.nextLine();

        Login user = new Login(username, password, cellPhone, firstName, lastName);

        System.out.println();
        System.out.println(user.registerUser());

        if (user.checkUserName() && user.checkPasswordComplexity() && user.checkCellPhoneNumber()) {

            System.out.println();
            System.out.println("===== Login =====");

            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            boolean loginStatus = user.loginUser(loginUsername, loginPassword);

            System.out.println(user.returnLoginStatus(loginStatus));
        }

        input.close();
    }
}

class Login {

    String username;
    String password;
    String cellPhone;
    String firstName;
    String lastName;

    Login(String u, String p, String c, String f, String l) {
        username = u;
        password = p;
        cellPhone = c;
        firstName = f;
        lastName = l;
    }

    boolean checkUserName() {
        return username.contains("_")
                && username.length() >= 6
                && username.length() <= 20;
    }

    boolean checkPasswordComplexity() {
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    boolean checkCellPhoneNumber() {
        return cellPhone.matches("^\\+27\\d{9}$");
    }

    String registerUser() {

        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is between 6 and 20 characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell phone number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }

        return "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell phone number successfully captured.\n"
                + "User has been registered successfully.";
    }

    boolean loginUser(String a, String b) {
        return a.equals(username) && b.equals(password);
    }

    String returnLoginStatus(boolean ok) {
        if (ok) {
            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}





